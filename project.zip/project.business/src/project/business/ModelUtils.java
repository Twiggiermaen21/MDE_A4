package project.business;


import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;


import project.*;


public class ModelUtils {
	public static University create() {
		University un = ProjectFactory.eINSTANCE.createUniversity();
		un.setName("Universita Degli Studi DellAquila");
	
		Employee em0 = ProjectFactory.eINSTANCE.createEmployee();
		em0.setName("Kacper Pudelko");
		em0.setPersonal_id(0);
		em0.setSalary(2220);
		Employee em1 = ProjectFactory.eINSTANCE.createEmployee();
		em1.setName("Andrzej Duda");
		em1.setPersonal_id(1);
		em0.setSalary(3220);
		Employee em2 = ProjectFactory.eINSTANCE.createEmployee();
		em2.setName("Michalina Kuczera");
		em2.setPersonal_id(2);
		em0.setSalary(4210);
		
		Role ro0 =  ProjectFactory.eINSTANCE.createRole();
		ro0.getRole().add(Roles.RECTOR);
		Role ro1 =  ProjectFactory.eINSTANCE.createRole();
		ro1.getRole().add(Roles.PRO_RECTOR);
		Role ro2 =  ProjectFactory.eINSTANCE.createRole();
		ro2.getRole().add(Roles.PROFESSOR);
		
		Task ta0 = ProjectFactory.eINSTANCE.createTask();
		ta0.getTask().add(Tasks.MANAGEMENT_UNIVERSITY);
		Task ta1 = ProjectFactory.eINSTANCE.createTask();
		ta1.getTask().add(Tasks.DEPUTY_RECTOR);
		Task ta2 = ProjectFactory.eINSTANCE.createTask();
		ta2.getTask().add(Tasks.TEACHING);
		
		
		Department de0 = ProjectFactory.eINSTANCE.createDepartment();
		de0.setName("Department of Human Studies");
		Department de1 = ProjectFactory.eINSTANCE.createDepartment();
		de1.setName("Department of Information Engineering Computer Science and Mathematics");	
		Department de2 = ProjectFactory.eINSTANCE.createDepartment();
		de2.setName("Department of Physical and Chemical Sciences");
		
		Course co0 = ProjectFactory.eINSTANCE.createCourse();
		co0.setName("Humanities");
		co0.setNumber("L10");
		Course co1 = ProjectFactory.eINSTANCE.createCourse();
		co1.setName("Computer Science");
		co1.setNumber("L31");
		Course co2 = ProjectFactory.eINSTANCE.createCourse();
		co2.setName("Chemistry and Materials Science");
		co2.setNumber("LM68");
		Course co3 = ProjectFactory.eINSTANCE.createCourse();
		co3.setName("Physics");
		co3.setNumber("LM17");
		
		Subject su0 = ProjectFactory.eINSTANCE.createSubject();
		su0.setName("HUMAN GEOGRAPHY");
		su0.setNumber("DQ0289");
		Subject su1 = ProjectFactory.eINSTANCE.createSubject();
		su1.setName("ITALIAN LITERATURE");
		su1.setNumber("DQ0031");
		Subject su2 = ProjectFactory.eINSTANCE.createSubject();
		su2.setName("PHYSICS");
		su2.setNumber("F0143");
		Subject su3 = ProjectFactory.eINSTANCE.createSubject();
		su3.setName("COMPUTER ARCHITECTURE");
		su3.setNumber("F1005");
		Subject su4 = ProjectFactory.eINSTANCE.createSubject();
		su4.setName("BASIC PRACTICE IN CHEMISTRY");
		su4.setNumber("F0056");
		Subject su5 = ProjectFactory.eINSTANCE.createSubject();
		su5.setName("GENERAL AND INORGANIC CHEMISTRY");
		su5.setNumber("F0036");
		Subject su6 = ProjectFactory.eINSTANCE.createSubject();
		su6.setName("MATHEMATICAL ANALYSIS I");
		su6.setNumber("F0002");
		Subject su7 = ProjectFactory.eINSTANCE.createSubject();
		su7.setName("GEOMETRY");
		su7.setNumber("F001");
		
		Student st0 = ProjectFactory.eINSTANCE.createStudent();
		st0.setName("Tekla Liupold");
		st0.setPersonal_id(0);
		st0.setDegree(Degree.MASTER);
		st0.setAge(19);
		Student st1 = ProjectFactory.eINSTANCE.createStudent();
		st1.setName("Cengiz Kristin");
		st1.setPersonal_id(1);
		st1.setDegree(Degree.BACHELOR);
		st1.setAge(22);
		Student st2 = ProjectFactory.eINSTANCE.createStudent();
		st2.setName("Godiva Sibylle");
		st2.setPersonal_id(2);
		st2.setDegree(Degree.BACHELOR);
		st2.setAge(21);
		Student st3 = ProjectFactory.eINSTANCE.createStudent();
		st3.setName("Jakub Placek");
		st3.setPersonal_id(3);
		st3.setDegree(Degree.BACHELOR);
		st3.setAge(22);
		Student st4 = ProjectFactory.eINSTANCE.createStudent();
		st4.setName("Jan Domek");
		st4.setPersonal_id(4);
		st4.setDegree(Degree.BACHELOR);
		st4.setAge(21);
		Student st5 = ProjectFactory.eINSTANCE.createStudent();
		st5.setName("Adam Nowak");
		st5.setPersonal_id(5);
		st5.setDegree(Degree.BACHELOR);
		st5.setAge(21);
		Student st6 = ProjectFactory.eINSTANCE.createStudent();
		st6.setName("Monika Piec");
		st6.setPersonal_id(6);
		st6.setDegree(Degree.BACHELOR);
		st6.setAge(23);
		Student st7 = ProjectFactory.eINSTANCE.createStudent();
		st7.setName("Mateusz Szczepek");
		st7.setPersonal_id(7);
		st7.setDegree(Degree.BACHELOR);
		st7.setAge(24);
		Student st8 = ProjectFactory.eINSTANCE.createStudent();
		st8.setName("Marcin Kopacz");
		st8.setPersonal_id(8);
		st8.setDegree(Degree.BACHELOR);
		st8.setAge(22);
		Student st9 = ProjectFactory.eINSTANCE.createStudent();
		st9.setName("Ola Mieszko");
		st9.setPersonal_id(9);
		st9.setDegree(Degree.BACHELOR);
		st9.setAge(29);
		Student st10 = ProjectFactory.eINSTANCE.createStudent();
		st10.setName("Adrian Nowak");
		st10.setPersonal_id(10);
		st10.setDegree(Degree.BACHELOR);
		st10.setAge(28);
		
		ro0.getTask().add(ta0);
		ro1.getTask().add(ta1);
		ro2.getTask().add(ta2);
			em0.getRole().add(ro0);
			em1.getRole().add(ro1);
			em2.getRole().add(ro2);
				un.getEmployee().add(em0);
				un.getEmployee().add(em1);
				un.getEmployee().add(em2);
				
				
	su0.getStudent().add(st0);		
	su1.getStudent().add(st1);	
	su2.getStudent().add(st2);	
	su3.getStudent().add(st3);	
	su4.getStudent().add(st4);	
	su5.getStudent().add(st5);	
	su6.getStudent().add(st6);	
	su6.getStudent().add(st7);	
	su7.getStudent().add(st8);	
	su7.getStudent().add(st10);
		co0.getSubject().add(su0);
		co0.getSubject().add(su1);
		co1.getSubject().add(su2);
		co1.getSubject().add(su3);
		co1.getSubject().add(su3);				
		co2.getSubject().add(su4);
		co2.getSubject().add(su5);
		co3.getSubject().add(su6);
		co3.getSubject().add(su7);
			de0.getCourse().add(co0);
			de1.getCourse().add(co1);
			de2.getCourse().add(co2);
			de2.getCourse().add(co3);
				un.getDepartment().add(de0);
				un.getDepartment().add(de1);
				un.getDepartment().add(de2);
		
		return un;
	}
	public final static String FILENAME = "projectLiveMDE.xmi";
	
	public static Diagnostic validate(University uv) {
		return Diagnostician.INSTANCE.validate(uv);
	}
	
	public static void main(String[] args) {
		University app = create();
		serializeModel(app, FILENAME);
		University libl = load(FILENAME);

		Diagnostic d = validate(libl);
		if (d.getSeverity() != Diagnostic.ERROR)
			System.out.println("the model is valid");
		
		else
			System.out.println("The model is not invalid");
		
		
	}
	
	public static University load(String fileName) {
		EPackage.Registry.INSTANCE.put(ProjectPackage.eNS_URI, ProjectPackage.eINSTANCE);
		ResourceSet resSet = new ResourceSetImpl();
		Resource resource = resSet.getResource(URI.createFileURI(fileName), true);
		
		University myUv = (University) resource.getContents().get(0);
		System.out.println(myUv);
		return myUv;
	}
	
	public static void serializeModel(University wm, String fileName) {
		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("xmi", new XMIResourceFactoryImpl());

		ResourceSet resSet = new ResourceSetImpl();

		Resource resource = resSet.createResource(URI.createURI(fileName));
		resource.getContents().add(wm);

		
		try {
			resource.save(Collections.EMPTY_MAP);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	
}
