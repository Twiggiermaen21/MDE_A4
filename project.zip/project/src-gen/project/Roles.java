/**
 */
package project;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Roles</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see project.ProjectPackage#getRoles()
 * @model
 * @generated
 */
public enum Roles implements Enumerator {
	/**
	 * The '<em><b>Worker</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WORKER_VALUE
	 * @generated
	 * @ordered
	 */
	WORKER(0, "worker", "worker"),

	/**
	 * The '<em><b>Professor</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROFESSOR_VALUE
	 * @generated
	 * @ordered
	 */
	PROFESSOR(1, "professor", "professor"),

	/**
	 * The '<em><b>Pro rector</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PRO_RECTOR_VALUE
	 * @generated
	 * @ordered
	 */
	PRO_RECTOR(2, "pro_rector", "pro_rector"),

	/**
	 * The '<em><b>Rector</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RECTOR_VALUE
	 * @generated
	 * @ordered
	 */
	RECTOR(3, "rector", "rector");

	/**
	 * The '<em><b>Worker</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WORKER
	 * @model name="worker"
	 * @generated
	 * @ordered
	 */
	public static final int WORKER_VALUE = 0;

	/**
	 * The '<em><b>Professor</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROFESSOR
	 * @model name="professor"
	 * @generated
	 * @ordered
	 */
	public static final int PROFESSOR_VALUE = 1;

	/**
	 * The '<em><b>Pro rector</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PRO_RECTOR
	 * @model name="pro_rector"
	 * @generated
	 * @ordered
	 */
	public static final int PRO_RECTOR_VALUE = 2;

	/**
	 * The '<em><b>Rector</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RECTOR
	 * @model name="rector"
	 * @generated
	 * @ordered
	 */
	public static final int RECTOR_VALUE = 3;

	/**
	 * An array of all the '<em><b>Roles</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Roles[] VALUES_ARRAY = new Roles[] { WORKER, PROFESSOR, PRO_RECTOR, RECTOR, };

	/**
	 * A public read-only list of all the '<em><b>Roles</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Roles> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Roles</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Roles get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Roles result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Roles</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Roles getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Roles result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Roles</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Roles get(int value) {
		switch (value) {
		case WORKER_VALUE:
			return WORKER;
		case PROFESSOR_VALUE:
			return PROFESSOR;
		case PRO_RECTOR_VALUE:
			return PRO_RECTOR;
		case RECTOR_VALUE:
			return RECTOR;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Roles(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //Roles
