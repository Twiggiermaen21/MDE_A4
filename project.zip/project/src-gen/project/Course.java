/**
 */
package project;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Course</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.Course#getSubject <em>Subject</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getCourse()
 * @model
 * @generated
 */
public interface Course extends NamedElement, NumberElement {
	/**
	 * Returns the value of the '<em><b>Subject</b></em>' containment reference list.
	 * The list contents are of type {@link project.Subject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subject</em>' containment reference list.
	 * @see project.ProjectPackage#getCourse_Subject()
	 * @model containment="true"
	 * @generated
	 */
	EList<Subject> getSubject();

} // Course
