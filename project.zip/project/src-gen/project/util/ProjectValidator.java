/**
 */
package project.util;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import project.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see project.ProjectPackage
 * @generated
 */
public class ProjectValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final ProjectValidator INSTANCE = new ProjectValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "project";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Student Unique ID' of 'University'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int UNIVERSITY__STUDENT_UNIQUE_ID = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Salary' of 'Employee'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int EMPLOYEE__SALARY = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Age' of 'Student'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int STUDENT__AGE = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Employee Unique ID' of 'University'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int UNIVERSITY__EMPLOYEE_UNIQUE_ID = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Department Unique Name' of 'University'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int UNIVERSITY__DEPARTMENT_UNIQUE_NAME = 2;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 5;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProjectValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return ProjectPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		switch (classifierID) {
		case ProjectPackage.UNIVERSITY:
			return validateUniversity((University) value, diagnostics, context);
		case ProjectPackage.EMPLOYEE:
			return validateEmployee((Employee) value, diagnostics, context);
		case ProjectPackage.ROLE:
			return validateRole((Role) value, diagnostics, context);
		case ProjectPackage.TASK:
			return validateTask((Task) value, diagnostics, context);
		case ProjectPackage.ID_ELEMENT:
			return validateIdElement((IdElement) value, diagnostics, context);
		case ProjectPackage.NAMED_ELEMENT:
			return validateNamedElement((NamedElement) value, diagnostics, context);
		case ProjectPackage.NUMBER_ELEMENT:
			return validateNumberElement((NumberElement) value, diagnostics, context);
		case ProjectPackage.DEPARTMENT:
			return validateDepartment((Department) value, diagnostics, context);
		case ProjectPackage.COURSE:
			return validateCourse((Course) value, diagnostics, context);
		case ProjectPackage.SUBJECT:
			return validateSubject((Subject) value, diagnostics, context);
		case ProjectPackage.STUDENT:
			return validateStudent((Student) value, diagnostics, context);
		case ProjectPackage.DEGREE:
			return validateDegree((Degree) value, diagnostics, context);
		case ProjectPackage.ROLES:
			return validateRoles((Roles) value, diagnostics, context);
		case ProjectPackage.TASKS:
			return validateTasks((Tasks) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUniversity(University university, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(university, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateUniversity_studentUniqueID(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateUniversity_employeeUniqueID(university, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateUniversity_departmentUniqueName(university, diagnostics, context);
		return result;
	}

	/**
	 * Validates the studentUniqueID constraint of '<em>University</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUniversity_studentUniqueID(University university, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return university.studentUniqueID(diagnostics, context);
	}

	/**
	 * Validates the employeeUniqueID constraint of '<em>University</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUniversity_employeeUniqueID(University university, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return university.employeeUniqueID(diagnostics, context);
	}

	/**
	 * Validates the departmentUniqueName constraint of '<em>University</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUniversity_departmentUniqueName(University university, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return university.departmentUniqueName(diagnostics, context);
	}

	/**
	 * Validates the uniqueID constraint of '<em>University</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */

	/**
	 * Validates the name constraint of '<em>University</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEmployee(Employee employee, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(employee, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(employee, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateEmployee_salary(employee, diagnostics, context);
		return result;
	}

	/**
	 * Validates the salary constraint of '<em>Employee</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEmployee_salary(Employee employee, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return employee.salary(diagnostics, context);
	}

	/**
	 * Validates the name constraint of '<em>Employee</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRole(Role role, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(role, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTask(Task task, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(task, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateIdElement(IdElement idElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(idElement, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNamedElement(NamedElement namedElement, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(namedElement, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNumberElement(NumberElement numberElement, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(numberElement, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDepartment(Department department, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(department, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCourse(Course course, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(course, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSubject(Subject subject, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(subject, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStudent(Student student, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(student, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(student, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateStudent_age(student, diagnostics, context);
		return result;
	}

	/**
	 * Validates the age constraint of '<em>Student</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStudent_age(Student student, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return student.age(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDegree(Degree degree, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRoles(Roles roles, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTasks(Tasks tasks, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //ProjectValidator
