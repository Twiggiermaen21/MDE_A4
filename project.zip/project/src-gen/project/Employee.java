/**
 */
package project;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Employee</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.Employee#getRole <em>Role</em>}</li>
 *   <li>{@link project.Employee#getSalary <em>Salary</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getEmployee()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='salary'"
 * @generated
 */
public interface Employee extends IdElement, NamedElement {
	/**
	 * Returns the value of the '<em><b>Role</b></em>' containment reference list.
	 * The list contents are of type {@link project.Role}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role</em>' containment reference list.
	 * @see project.ProjectPackage#getEmployee_Role()
	 * @model containment="true"
	 * @generated
	 */
	EList<Role> getRole();

	/**
	 * Returns the value of the '<em><b>Salary</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Salary</em>' attribute.
	 * @see #setSalary(int)
	 * @see project.ProjectPackage#getEmployee_Salary()
	 * @model required="true"
	 * @generated
	 */
	int getSalary();

	/**
	 * Sets the value of the '{@link project.Employee#getSalary <em>Salary</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Salary</em>' attribute.
	 * @see #getSalary()
	 * @generated
	 */
	void setSalary(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='salary &gt;= 2000'"
	 * @generated
	 */
	boolean salary(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Employee
