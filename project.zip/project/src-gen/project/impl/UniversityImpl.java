/**
 */
package project.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.ocl.pivot.evaluation.Executor;
import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.library.collection.CollectionAsSetOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionSizeOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;
import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;
import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.OrderedSetValue;
import org.eclipse.ocl.pivot.values.SequenceValue;
import org.eclipse.ocl.pivot.values.SequenceValue.Accumulator;
import org.eclipse.ocl.pivot.values.SetValue;
import project.Course;
import project.Department;
import project.Employee;
import project.ProjectPackage;
import project.ProjectTables;
import project.Student;
import project.Subject;
import project.University;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>University</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link project.impl.UniversityImpl#getEmployee <em>Employee</em>}</li>
 *   <li>{@link project.impl.UniversityImpl#getDepartment <em>Department</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UniversityImpl extends NamedElementImpl implements University {
	/**
	 * The cached value of the '{@link #getEmployee() <em>Employee</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployee()
	 * @generated
	 * @ordered
	 */
	protected EList<Employee> employee;

	/**
	 * The cached value of the '{@link #getDepartment() <em>Department</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDepartment()
	 * @generated
	 * @ordered
	 */
	protected EList<Department> department;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UniversityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProjectPackage.Literals.UNIVERSITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Employee> getEmployee() {
		if (employee == null) {
			employee = new EObjectContainmentEList<Employee>(Employee.class, this, ProjectPackage.UNIVERSITY__EMPLOYEE);
		}
		return employee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Department> getDepartment() {
		if (department == null) {
			department = new EObjectContainmentEList<Department>(Department.class, this,
					ProjectPackage.UNIVERSITY__DEPARTMENT);
		}
		return department;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean studentUniqueID(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "University::studentUniqueID";
		try {
			/**
			 *
			 * inv studentUniqueID:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[1] = department.course.subject.student.personal_id->asSet()
			 *         ->size() =
			 *         department.course.subject.student.personal_id->size()
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					ProjectPackage.Literals.UNIVERSITY___STUDENT_UNIQUE_ID__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, ProjectTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			} else {
				final /*@NonInvalid*/ List<Department> department_0 = this.getDepartment();
				final /*@NonInvalid*/ OrderedSetValue BOXED_department_0 = idResolver
						.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Department, department_0);
				/*@Thrown*/ Accumulator accumulator = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_CLSSid_Course);
				Iterator<Object> ITERATOR__1_3 = BOXED_department_0.iterator();
				/*@NonInvalid*/ SequenceValue collect_6;
				while (true) {
					if (!ITERATOR__1_3.hasNext()) {
						collect_6 = accumulator;
						break;
					}
					/*@NonInvalid*/ Department _1_3 = (Department) ITERATOR__1_3.next();
					/**
					 * course
					 */
					final /*@NonInvalid*/ List<Course> course_0 = _1_3.getCourse();
					final /*@NonInvalid*/ OrderedSetValue BOXED_course_0 = idResolver
							.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Course, course_0);
					//
					for (Object value : BOXED_course_0.flatten().getElements()) {
						accumulator.add(value);
					}
				}
				/*@Thrown*/ Accumulator accumulator_0 = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_CLSSid_Subject);
				Iterator<Object> ITERATOR__1_4 = collect_6.iterator();
				/*@NonInvalid*/ SequenceValue collect_5;
				while (true) {
					if (!ITERATOR__1_4.hasNext()) {
						collect_5 = accumulator_0;
						break;
					}
					/*@NonInvalid*/ Course _1_4 = (Course) ITERATOR__1_4.next();
					/**
					 * subject
					 */
					final /*@NonInvalid*/ List<Subject> subject_0 = _1_4.getSubject();
					final /*@NonInvalid*/ OrderedSetValue BOXED_subject_0 = idResolver
							.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Subject, subject_0);
					//
					for (Object value : BOXED_subject_0.flatten().getElements()) {
						accumulator_0.add(value);
					}
				}
				/*@Thrown*/ Accumulator accumulator_1 = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_CLSSid_Student);
				Iterator<Object> ITERATOR__1_5 = collect_5.iterator();
				/*@NonInvalid*/ SequenceValue collect_4;
				while (true) {
					if (!ITERATOR__1_5.hasNext()) {
						collect_4 = accumulator_1;
						break;
					}
					/*@NonInvalid*/ Subject _1_5 = (Subject) ITERATOR__1_5.next();
					/**
					 * student
					 */
					final /*@NonInvalid*/ List<Student> student_0 = _1_5.getStudent();
					final /*@NonInvalid*/ OrderedSetValue BOXED_student_0 = idResolver
							.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Student, student_0);
					//
					for (Object value : BOXED_student_0.flatten().getElements()) {
						accumulator_1.add(value);
					}
				}
				/*@Thrown*/ Accumulator accumulator_2 = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_DATAid_EInt);
				Iterator<Object> ITERATOR__1_6 = collect_4.iterator();
				/*@NonInvalid*/ SequenceValue collect_3;
				while (true) {
					if (!ITERATOR__1_6.hasNext()) {
						collect_3 = accumulator_2;
						break;
					}
					/*@NonInvalid*/ Student _1_6 = (Student) ITERATOR__1_6.next();
					/**
					 * personal_id
					 */
					final /*@NonInvalid*/ int personal_id_0 = _1_6.getPersonal_id();
					final /*@NonInvalid*/ IntegerValue BOXED_personal_id_0 = ValueUtil.integerValueOf(personal_id_0);
					//
					accumulator_2.add(BOXED_personal_id_0);
				}
				final /*@NonInvalid*/ SetValue asSet = CollectionAsSetOperation.INSTANCE.evaluate(collect_3);
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(asSet);
				final /*@NonInvalid*/ IntegerValue size_0 = CollectionSizeOperation.INSTANCE.evaluate(collect_3);
				final /*@NonInvalid*/ boolean result = size.equals(size_0);
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, result, ProjectTables.INT_0)
						.booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean employeeUniqueID(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "University::employeeUniqueID";
		try {
			/**
			 *
			 * inv employeeUniqueID:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[1] = employee.personal_id->asSet()
			 *         ->size() =
			 *         employee.personal_id->size()
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					ProjectPackage.Literals.UNIVERSITY___EMPLOYEE_UNIQUE_ID__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, ProjectTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			} else {
				final /*@NonInvalid*/ List<Employee> employee_0 = this.getEmployee();
				final /*@NonInvalid*/ OrderedSetValue BOXED_employee_0 = idResolver
						.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Employee, employee_0);
				/*@Thrown*/ Accumulator accumulator = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_DATAid_EInt);
				Iterator<Object> ITERATOR__1_0 = BOXED_employee_0.iterator();
				/*@NonInvalid*/ SequenceValue collect_0;
				while (true) {
					if (!ITERATOR__1_0.hasNext()) {
						collect_0 = accumulator;
						break;
					}
					/*@NonInvalid*/ Employee _1_0 = (Employee) ITERATOR__1_0.next();
					/**
					 * personal_id
					 */
					final /*@NonInvalid*/ int personal_id_0 = _1_0.getPersonal_id();
					final /*@NonInvalid*/ IntegerValue BOXED_personal_id_0 = ValueUtil.integerValueOf(personal_id_0);
					//
					accumulator.add(BOXED_personal_id_0);
				}
				final /*@NonInvalid*/ SetValue asSet = CollectionAsSetOperation.INSTANCE.evaluate(collect_0);
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(asSet);
				final /*@NonInvalid*/ IntegerValue size_0 = CollectionSizeOperation.INSTANCE.evaluate(collect_0);
				final /*@NonInvalid*/ boolean result = size.equals(size_0);
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, result, ProjectTables.INT_0)
						.booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean departmentUniqueName(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "University::departmentUniqueName";
		try {
			/**
			 *
			 * inv departmentUniqueName:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[1] = department.name->asSet()
			 *         ->size() =
			 *         department.name->size()
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					ProjectPackage.Literals.UNIVERSITY___DEPARTMENT_UNIQUE_NAME__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, ProjectTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			} else {
				final /*@NonInvalid*/ List<Department> department_0 = this.getDepartment();
				final /*@NonInvalid*/ OrderedSetValue BOXED_department_0 = idResolver
						.createOrderedSetOfAll(ProjectTables.ORD_CLSSid_Department, department_0);
				/*@Thrown*/ Accumulator accumulator = ValueUtil
						.createSequenceAccumulatorValue(ProjectTables.SEQ_PRIMid_String);
				Iterator<Object> ITERATOR__1_0 = BOXED_department_0.iterator();
				/*@NonInvalid*/ SequenceValue collect_0;
				while (true) {
					if (!ITERATOR__1_0.hasNext()) {
						collect_0 = accumulator;
						break;
					}
					/*@NonInvalid*/ Department _1_0 = (Department) ITERATOR__1_0.next();
					/**
					 * name
					 */
					final /*@NonInvalid*/ String name_0 = _1_0.getName();
					//
					accumulator.add(name_0);
				}
				final /*@NonInvalid*/ SetValue asSet = CollectionAsSetOperation.INSTANCE.evaluate(collect_0);
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(asSet);
				final /*@NonInvalid*/ IntegerValue size_0 = CollectionSizeOperation.INSTANCE.evaluate(collect_0);
				final /*@NonInvalid*/ boolean result = size.equals(size_0);
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, result, ProjectTables.INT_0)
						.booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ProjectPackage.UNIVERSITY__EMPLOYEE:
			return ((InternalEList<?>) getEmployee()).basicRemove(otherEnd, msgs);
		case ProjectPackage.UNIVERSITY__DEPARTMENT:
			return ((InternalEList<?>) getDepartment()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ProjectPackage.UNIVERSITY__EMPLOYEE:
			return getEmployee();
		case ProjectPackage.UNIVERSITY__DEPARTMENT:
			return getDepartment();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ProjectPackage.UNIVERSITY__EMPLOYEE:
			getEmployee().clear();
			getEmployee().addAll((Collection<? extends Employee>) newValue);
			return;
		case ProjectPackage.UNIVERSITY__DEPARTMENT:
			getDepartment().clear();
			getDepartment().addAll((Collection<? extends Department>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ProjectPackage.UNIVERSITY__EMPLOYEE:
			getEmployee().clear();
			return;
		case ProjectPackage.UNIVERSITY__DEPARTMENT:
			getDepartment().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ProjectPackage.UNIVERSITY__EMPLOYEE:
			return employee != null && !employee.isEmpty();
		case ProjectPackage.UNIVERSITY__DEPARTMENT:
			return department != null && !department.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ProjectPackage.UNIVERSITY___EMPLOYEE_UNIQUE_ID__DIAGNOSTICCHAIN_MAP:
			return employeeUniqueID((DiagnosticChain) arguments.get(0), (Map<Object, Object>) arguments.get(1));
		case ProjectPackage.UNIVERSITY___DEPARTMENT_UNIQUE_NAME__DIAGNOSTICCHAIN_MAP:
			return departmentUniqueName((DiagnosticChain) arguments.get(0), (Map<Object, Object>) arguments.get(1));
		case ProjectPackage.UNIVERSITY___STUDENT_UNIQUE_ID__DIAGNOSTICCHAIN_MAP:
			return studentUniqueID((DiagnosticChain) arguments.get(0), (Map<Object, Object>) arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

} //UniversityImpl
